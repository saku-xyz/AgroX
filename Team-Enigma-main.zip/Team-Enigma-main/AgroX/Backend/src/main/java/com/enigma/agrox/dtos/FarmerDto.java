package com.enigma.agrox.dtos;

public class FarmerDto {
	private int farmerId;
	private String farmerName;
	private String farmerContactNumber;
	private String farmerLocation;
	private String farmerUsername;
	private String farmerPassword;
	public int getFarmerId() {
		return farmerId;
	}
	public void setFarmerId(int farmerId) {
		this.farmerId = farmerId;
	}
	public String getFarmerName() {
		return farmerName;
	}
	public void setFarmerName(String farmerName) {
		this.farmerName = farmerName;
	}
	public String getFarmerContactNumber() {
		return farmerContactNumber;
	}
	public void setFarmerContactNumber(String farmerContactNumber) {
		this.farmerContactNumber = farmerContactNumber;
	}
	public String getFarmerLocation() {
		return farmerLocation;
	}
	public void setFarmerLocation(String farmerLocation) {
		this.farmerLocation = farmerLocation;
	}
	public String getFarmerUsername() {
		return farmerUsername;
	}
	public void setFarmerUsername(String farmerUsername) {
		this.farmerUsername = farmerUsername;
	}
	public String getFarmerPassword() {
		return farmerPassword;
	}
	public void setFarmerPassword(String farmerPassword) {
		this.farmerPassword = farmerPassword;
	}
	
	
	
}
