package com.enigma.agrox;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AgroXBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(AgroXBackendApplication.class, args);
	}

}
