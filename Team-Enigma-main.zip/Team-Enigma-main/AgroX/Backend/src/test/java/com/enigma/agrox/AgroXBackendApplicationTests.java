package com.enigma.agrox;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AgroXBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
